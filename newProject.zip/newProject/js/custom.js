/*global $, alert, console*/
$(function () {
    
   'use strict'; 
    
    $('html').niceScroll({
        cursorwidth : 10,
        cursorborder: '1px solid #ccc'
    });
    
    $('.header').height($(window).height());
    
    $('.header .arrow i').click( function () {
        
        $('html, body').animate({
            
            scrollTop: $('.features').offset().top
        }, 1000);
    });
    
    $('.our-works').click(function () {
        
        $('html, body').animate({
            
            scrollTop: $('.our-work').offset().top
        }, 1000);
    });
    
    $('.hire').click(function () {
        
        $('html, body').animate({
            
            scrollTop: $('.contact').offset().top
        }, 1000);
    });
    
    $('.show-more').click(function () {
        
       $('.our-work .hidden').toggle(1000); 
    });
    
    var rightArrow = $('.testim .fa-chevron-right'),
        leftArrow = $('.testim .fa-chevron-left');
    
    function checkClients() {
        
        if ($('.client:first').hasClass('active')) {
            
            leftArrow.fadeOut();
       
        } else {
            
            leftArrow.fadeIn();
        }
        $('.client:last').hasClass('active') ? rightArrow.fadeOut() : rightArrow.fadeIn();
    }
    
    checkClients();
    
    $('.testim i').click(function () {
        
        if ($(this).hasClass('fa-chevron-right')) {
            
            $('.testim .active').fadeOut(100, function () { 
                
                $(this).removeClass('active').next('.client').addClass('active').fadeIn();
            
            checkClients();
            
            });
            
        } else {
            
             $('.testim .active').fadeOut(100, function () { 
                
                $(this).removeClass('active').prev('.client').addClass('active').fadeIn();
            
            checkClients();
            
            });
        }
    });
    
});